/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { BooksList } from './components/BooksList';
import { MembersList } from './components/MembersList';
import { BorrowingsList } from './components/BorrowingsList';
import { ReservationsList } from './components/ReservationsList';
import { FinesList } from './components/FinesList';
import { ReportsList } from './components/ReportsList';
import { Login } from './components/Login';
import { mockBooks, mockUsers, mockRecords, mockReservations, mockFines, mockFavorites, mockNotifications } from './data';
import { Moon, Sun } from 'lucide-react';
import { UserDashboard } from './components/UserDashboard';
import { UserCatalog } from './components/UserCatalog';
import { UserFavorites } from './components/UserFavorites';
import { UserNotifications } from './components/UserNotifications';
import { UserBorrowings } from './components/UserBorrowings';
import { UserReservations } from './components/UserReservations';
import { UserFines } from './components/UserFines';
import { UserProfile } from './components/UserProfile';
import { Book, User, BorrowingRecord, Reservation, Fine, Favorite, Notification } from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [currentTab, setCurrentTab] = useState('dashboard');
  
  // Lifted Application State
  const [books, setBooks] = useState<Book[]>(mockBooks);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [records, setRecords] = useState<BorrowingRecord[]>(mockRecords);
  const [reservations, setReservations] = useState<Reservation[]>(mockReservations);
  const [fines, setFines] = useState<Fine[]>(mockFines);
  const [favorites, setFavorites] = useState<Favorite[]>(mockFavorites);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);

  // Authentication & Credentials State
  const [credentials, setCredentials] = useState<Record<string, string>>({
    'charan': '111',
    'rishi': '111',
    'sudha': '111',
    'admin': 'admin123'
  });

  const handleRegister = (username: string, pass: string) => {
    const normalized = username.toLowerCase().trim();
    if (credentials[normalized] || users.some(u => u.email === normalized)) {
      return false; // User already exists
    }
    
    // Add credentials
    setCredentials(prev => ({ ...prev, [normalized]: pass }));
    
    // Create member profile
    const newUser: User = {
      id: `u${Date.now()}`,
      name: username,
      email: normalized,
      phone: '',
      location: '',
      role: 'Member',
      joinedDate: new Date().toISOString()
    };
    
    setUsers(prev => [...prev, newUser]);
    return true;
  };

  // Handlers for Application State
  const handleMarkReturned = (recordId: string) => {
    setRecords(records.map(r => r.id === recordId ? { ...r, status: 'Returned' } : r));
  };

  const handleCancelReservation = (reservationId: string) => {
    setReservations(reservations.map(r => r.id === reservationId ? { ...r, status: 'Cancelled' } : r));
  };

  const handlePayFine = (fineId: string) => {
    setFines(fines.map(f => f.id === fineId ? { ...f, status: 'Paid' } : f));
  };

  const handleToggleFavorite = (bookId: string) => {
    if (!loggedInUser) return;
    const exists = favorites.find(f => f.userId === loggedInUser.id && f.bookId === bookId);
    if (exists) {
      setFavorites(favorites.filter(f => f.id !== exists.id));
    } else {
      setFavorites([...favorites, { id: `fav${Date.now()}`, userId: loggedInUser.id, bookId }]);
    }
  };

  const handleMarkNotificationRead = (notificationId: string) => {
    setNotifications(notifications.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
  };

  const handleMarkAllNotificationsRead = () => {
    if (!loggedInUser) return;
    setNotifications(notifications.map(n => n.userId === loggedInUser.id ? { ...n, isRead: true } : n));
  };
  
  const [isDarkMode, setIsDarkMode] = useState(() => {
    if (typeof window !== 'undefined') {
      return document.documentElement.classList.contains('dark') ||
              window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  const toggleDarkMode = () => setIsDarkMode(!isDarkMode);

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentTab('dashboard');
  };

  const handleLogin = (username: string) => {
    setCurrentUser(username);
    setCurrentTab(username === 'admin' ? 'dashboard' : 'user-dashboard');
  };

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-neutral-100 flex items-center justify-center p-4">
        <Login 
          onLogin={handleLogin} 
          onRegister={handleRegister}
          credentials={credentials}
        />
      </div>
    );
  }

  const loggedInUser = users.find(u => u.email === currentUser);
  const unreadNotificationCount = notifications.filter(n => n.userId === loggedInUser?.id && !n.isRead).length;

  return (
    <div className="min-h-screen bg-[#f8fafc] dark:bg-slate-900 flex font-sans transition-colors duration-200">
      <Sidebar 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        currentUser={currentUser}
        onLogout={handleLogout}
        isDarkMode={isDarkMode}
        toggleDarkMode={toggleDarkMode}
        unreadNotificationCount={unreadNotificationCount}
      />
      
      <main className="flex-1 overflow-auto p-10">
        <div className="max-w-[1200px] mx-auto">
          {/* Admin Views */}
          {currentTab === 'dashboard' && (
            <Dashboard 
              books={books} 
              users={users}
              records={records}
              reservations={reservations}
              fines={fines}
            />
          )}
          {currentTab === 'books' && <BooksList books={books} />}
          {currentTab === 'members' && <MembersList users={users} records={records} />}
          {currentTab === 'borrowings' && (
            <BorrowingsList 
              books={books} 
              users={users} 
              records={records} 
              onMarkReturned={handleMarkReturned} 
            />
          )}
          {currentTab === 'reservations' && (
            <ReservationsList 
              books={books} 
              users={users} 
              reservations={reservations}
              onCancelReservation={handleCancelReservation}
            />
          )}
          {currentTab === 'fines' && (
            <FinesList 
              fines={fines} 
              users={users} 
              books={books} 
              records={records}
              onPayFine={handlePayFine}
            />
          )}
          {currentTab === 'reports' && (
            <ReportsList 
              fines={fines} 
              records={records} 
              users={users} 
              books={books} 
            />
          )}

          {/* Member Views */}
          {currentTab === 'user-dashboard' && loggedInUser && (
            <UserDashboard 
              user={loggedInUser}
              books={books}
              records={records}
              reservations={reservations}
              fines={fines}
            />
          )}
          {currentTab === 'user-catalog' && loggedInUser && (
            <UserCatalog 
              books={books} 
              user={loggedInUser}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
            />
          )}
          {currentTab === 'user-favorites' && loggedInUser && (
            <UserFavorites 
              books={books}
              user={loggedInUser}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
            />
          )}
          {currentTab === 'user-notifications' && loggedInUser && (
            <UserNotifications 
              user={loggedInUser}
              notifications={notifications}
              onMarkRead={handleMarkNotificationRead}
              onMarkAllRead={handleMarkAllNotificationsRead}
            />
          )}
          {currentTab === 'user-borrowings' && loggedInUser && (
            <UserBorrowings 
              user={loggedInUser}
              books={books}
              records={records}
            />
          )}
          {currentTab === 'user-reservations' && loggedInUser && (
            <UserReservations 
              user={loggedInUser}
              books={books}
              reservations={reservations}
            />
          )}
          {currentTab === 'user-fines' && loggedInUser && (
            <UserFines 
              user={loggedInUser}
              fines={fines}
            />
          )}
          {currentTab === 'user-profile' && loggedInUser && (
            <UserProfile 
              user={loggedInUser}
              onUpdate={(updatedUser) => {
                setUsers(users.map(u => u.id === updatedUser.id ? updatedUser : u));
              }}
            />
          )}
        </div>
      </main>
    </div>
  );
}
