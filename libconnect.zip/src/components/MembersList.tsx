import { User, BorrowingRecord } from '../types';
import { Search, Mail, Phone, MapPin } from 'lucide-react';

interface MembersListProps {
  users: User[];
  records: BorrowingRecord[];
}

export function MembersList({ users, records }: MembersListProps) {
  const members = users.filter(u => u.role === 'Member');

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">Member Management</h1>
        <p className="text-[15px] text-slate-500 mt-1">View and manage library member accounts.</p>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm p-2 mb-6">
        <div className="relative w-full">
          <Search className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
          <input 
            type="text" 
            placeholder="Search members by name, email, or phone..." 
            className="w-full pl-12 pr-4 py-2.5 bg-white border-0 rounded-lg text-[15px] text-slate-800 focus:outline-none focus:ring-0 placeholder:text-slate-400"
          />
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[800px]">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                <th className="px-6 py-4">MEMBER DETAILS</th>
                <th className="px-6 py-4">CONTACT</th>
                <th className="px-6 py-4">LOCATION</th>
                <th className="px-6 py-4 text-center">ACTIVE BORROWS</th>
                <th className="px-6 py-4 text-right">JOINED</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {members.map((user) => {
                const activeBorrows = records.filter(r => r.userId === user.id && (r.status === 'Active' || r.status === 'Overdue')).length;
                
                return (
                  <tr key={user.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-[#e6f7f5] text-[#008f7a] flex items-center justify-center text-[15px] font-bold uppercase">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-[15px] text-slate-900">{user.name}</div>
                          <div className="text-[12px] text-slate-500 mt-0.5 border border-slate-200 bg-slate-50 rounded px-1.5 py-0.5 inline-block">Member ID: {user.email}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 space-y-1">
                      <div className="flex items-center gap-2 text-[13px] text-slate-600">
                        <Mail className="w-3.5 h-3.5 text-slate-400" />
                        {user.email}
                      </div>
                      <div className="flex items-center gap-2 text-[13px] text-slate-600">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        {user.phone}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2 text-[14px] text-slate-600">
                        <MapPin className="w-4 h-4 text-slate-400" />
                        {user.location}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`inline-flex items-center justify-center min-w-[24px] h-6 rounded-full text-[12px] font-bold ${
                        activeBorrows > 0 ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {activeBorrows}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right text-[14px] text-slate-600">
                      {new Date(user.joinedDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
