import { Notification, User } from '../types';
import { Bell, Check, Info, AlertCircle, CheckCircle2 } from 'lucide-react';

interface UserNotificationsProps {
  user: User;
  notifications: Notification[];
  onMarkRead: (notificationId: string) => void;
  onMarkAllRead: () => void;
}

export function UserNotifications({ user, notifications, onMarkRead, onMarkAllRead }: UserNotificationsProps) {
  const userNotifications = notifications
    .filter(n => n.userId === user.id)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
  const unreadCount = userNotifications.filter(n => !n.isRead).length;

  const getIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertCircle className="w-5 h-5 text-amber-500" />;
      case 'success': return <CheckCircle2 className="w-5 h-5 text-teal-500" />;
      case 'info':
      default: return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-[28px] font-bold text-slate-800 tracking-tight dark:text-white">Notifications</h1>
          <p className="text-[15px] text-slate-500 dark:text-slate-400 mt-1">
            You have {unreadCount} unread message{unreadCount !== 1 ? 's' : ''}
          </p>
        </div>
        {unreadCount > 0 && (
          <button
            onClick={onMarkAllRead}
            className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-[14px] font-medium transition-colors"
          >
            <Check className="w-4 h-4" />
            Mark all as read
          </button>
        )}
      </div>

      <div className="bg-white dark:bg-[#0f172a] rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        {userNotifications.length === 0 ? (
          <div className="p-12 text-center">
            <Bell className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
            <h3 className="text-[16px] font-bold text-slate-800 dark:text-slate-200">You're all caught up!</h3>
            <p className="text-[14px] text-slate-500 dark:text-slate-400 mt-1">No new notifications to show.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/50">
            {userNotifications.map(notification => (
              <div 
                key={notification.id} 
                className={`p-6 flex gap-4 transition-colors ${
                  notification.isRead 
                    ? 'bg-transparent' 
                    : 'bg-teal-50/50 dark:bg-teal-900/10'
                }`}
              >
                <div className="flex-shrink-0 mt-1">
                  {getIcon(notification.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h4 className={`text-[15px] font-semibold ${notification.isRead ? 'text-slate-700 dark:text-slate-300' : 'text-slate-900 dark:text-slate-100'}`}>
                        {notification.title}
                      </h4>
                      <p className={`mt-1 text-[14px] ${notification.isRead ? 'text-slate-500 dark:text-slate-400' : 'text-slate-600 dark:text-slate-300'}`}>
                        {notification.message}
                      </p>
                      <div className="mt-2 text-[12px] text-slate-400 font-medium">
                        {new Date(notification.date).toLocaleDateString('en-US', { 
                          month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' 
                        })}
                      </div>
                    </div>
                    
                    {!notification.isRead && (
                      <button 
                        onClick={() => onMarkRead(notification.id)}
                        className="flex-shrink-0 w-3 h-3 rounded-full bg-teal-500 mt-1 hover:scale-125 transition-transform"
                        title="Mark as read"
                      />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
