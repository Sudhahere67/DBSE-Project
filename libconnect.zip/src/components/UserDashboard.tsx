import { Book, User, BorrowingRecord, Reservation, Fine } from '../types';
import { BookOpen, Bookmark, Clock, AlertCircle } from 'lucide-react';

interface UserDashboardProps {
  user: User;
  books: Book[];
  records: BorrowingRecord[];
  reservations: Reservation[];
  fines: Fine[];
}

export function UserDashboard({ user, books, records, reservations, fines }: UserDashboardProps) {
  const activeRecords = records.filter(r => r.userId === user.id && (r.status === 'Active' || r.status === 'Overdue'));
  const activeReservations = reservations.filter(r => r.userId === user.id && r.status === 'Pending');
  const outstandingFines = fines.filter(f => f.userId === user.id && f.status === 'Pending');
  
  const totalFines = outstandingFines.reduce((sum, f) => sum + f.amount, 0);

  // Simplified "Due within 3 days" (since we use mock dates, let's just count Overdue or near due)
  // For the screenshot consistency, it shows 0.
  const dueSoon = 0; 

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">Welcome back, {user.name}</h1>
        <p className="text-[15px] text-slate-500 mt-1">Here's what's happening with your library account.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-slate-500 text-[12px] font-medium mb-2">Currently Borrowed</h3>
            <div className="text-[28px] font-bold text-slate-900 leading-none">{activeRecords.length}</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-[#e6f7f5] text-[#008f7a] flex items-center justify-center">
            <BookOpen className="w-5 h-5" />
          </div>
        </div>
        
        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-slate-500 text-[12px] font-medium mb-2">Reserved Books</h3>
            <div className="text-[28px] font-bold text-slate-900 leading-none">{activeReservations.length}</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-amber-50 text-amber-600 flex items-center justify-center">
            <Bookmark className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-slate-500 text-[12px] font-medium mb-2">Due Within 3 Days</h3>
            <div className="text-[28px] font-bold text-slate-900 leading-none">{dueSoon}</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center">
            <Clock className="w-5 h-5" />
          </div>
        </div>

        <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm flex items-center justify-between">
          <div>
            <h3 className="text-slate-500 text-[12px] font-medium mb-2">Outstanding Fines</h3>
            <div className="text-[28px] font-bold text-red-600 leading-none">₹{totalFines}</div>
          </div>
          <div className="w-10 h-10 rounded-full bg-red-50 text-red-600 flex items-center justify-center">
            <AlertCircle className="w-5 h-5" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-[16px] font-medium text-slate-900">Current Borrowings</h2>
              <button className="text-[13px] font-medium text-[#008f7a] hover:text-[#007a68]">View all</button>
            </div>
            <div className="p-2">
              {activeRecords.length === 0 ? (
                <div className="p-8 text-center text-slate-500 text-[14px]">No active borrowings.</div>
              ) : (
                activeRecords.map(record => {
                  const book = books.find(b => b.id === record.bookId);
                  if (!book) return null;
                  const dueStr = new Date(record.dueDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
                  
                  return (
                    <div key={record.id} className="flex items-center justify-between p-4 hover:bg-slate-50 transition-colors rounded-lg mx-2 mb-2">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-16 bg-slate-200 rounded-md bg-cover bg-center" style={{ backgroundImage: book.coverUrl ? `url(${book.coverUrl})` : 'none' }}>
                          {!book.coverUrl && <div className="w-full h-full flex items-center justify-center text-[10px] text-slate-400 text-center p-1">{book.title}</div>}
                        </div>
                        <div>
                          <div className="font-semibold text-[15px] text-slate-900">{book.title}</div>
                          <div className="text-[13px] text-slate-500 mt-0.5">{book.author}</div>
                          <div className="text-[12px] text-slate-500 mt-1">Due: {dueStr}</div>
                        </div>
                      </div>
                      <button className="px-4 py-1.5 bg-[#e6f7f5] text-[#008f7a] font-medium text-[13px] rounded-lg">
                        View
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-[16px] font-medium text-slate-900">My Reservations</h2>
              <button className="text-[13px] font-medium text-[#008f7a] hover:text-[#007a68]">View all</button>
            </div>
            <div className="p-8 text-center">
              {activeReservations.length === 0 ? (
                <p className="text-[14px] text-slate-500">No active reservations.</p>
              ) : (
                <p className="text-[14px] text-slate-500">{activeReservations.length} active reservation(s).</p>
              )}
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-[16px] font-medium text-slate-900">Outstanding Fines</h2>
              <button className="text-[13px] font-medium text-[#008f7a] hover:text-[#007a68]">View all</button>
            </div>
            <div className="p-8 text-center">
              {totalFines === 0 ? (
                <p className="text-[14px] text-slate-500">No outstanding fines. Great job!</p>
              ) : (
                <p className="text-[14px] text-red-600 font-medium">₹{totalFines} due.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
