import { BookOpen, Users, LayoutDashboard, Settings, LogOut, ClipboardList, Clock, AlertCircle, BarChart2, Moon, Sun, Heart, Bell } from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  currentUser: string;
  onLogout: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  unreadNotificationCount?: number;
}

export function Sidebar({ currentTab, setCurrentTab, currentUser, onLogout, isDarkMode, toggleDarkMode, unreadNotificationCount = 0 }: SidebarProps) {
  const adminNavItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'books', label: 'Books', icon: BookOpen },
    { id: 'members', label: 'Members', icon: Users },
    { id: 'borrowings', label: 'Borrowings', icon: ClipboardList },
    { id: 'reservations', label: 'Reservations', icon: Clock },
    { id: 'fines', label: 'Fines', icon: AlertCircle },
    { id: 'reports', label: 'Reports', icon: BarChart2 },
  ];

  const memberNavItems = [
    { id: 'user-dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'user-catalog', label: 'Catalog', icon: BookOpen },
    { id: 'user-favorites', label: 'My Favorites', icon: Heart },
    { id: 'user-borrowings', label: 'My Borrowings', icon: ClipboardList },
    { id: 'user-reservations', label: 'My Reservations', icon: Clock },
    { id: 'user-fines', label: 'My Fines', icon: AlertCircle },
    { id: 'user-notifications', label: 'Notifications', icon: Bell, badge: unreadNotificationCount },
    { id: 'user-profile', label: 'Profile', icon: Users },
  ];

  const navItems = currentUser === 'admin' ? adminNavItems : memberNavItems;

  return (
    <aside className="w-64 border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0f172a] h-screen flex flex-col font-sans transition-colors duration-200">
      <div className="h-16 flex items-center px-6 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2 text-[#008f7a] dark:text-teal-400">
          {/* Custom Logo Icon */}
          <div className="flex items-end gap-0.5 h-5">
            <div className="w-[3px] h-3 bg-[#008f7a] dark:bg-teal-400 rounded-full"></div>
            <div className="w-[3px] h-5 bg-[#008f7a] dark:bg-teal-400 rounded-full"></div>
            <div className="w-[3px] h-4 bg-[#008f7a] dark:bg-teal-400 rounded-full"></div>
            <div className="w-[3px] h-5 bg-[#008f7a] dark:bg-teal-400 rounded-full rotate-[20deg] transform origin-bottom"></div>
          </div>
          <span className="font-bold text-[18px] tracking-tight dark:text-white">LibraryHub</span>
        </div>
      </div>
      
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          const badge = 'badge' in item ? item.badge : undefined;
          
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-[14px] font-medium transition-colors ${
                isActive 
                  ? 'bg-[#e6f7f5] dark:bg-teal-900/40 text-[#008f7a] dark:text-teal-400' 
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className="w-4 h-4" />
                {item.label}
              </div>
              {badge !== undefined && badge > 0 && (
                <span className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[11px] font-bold">
                  {badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
      
      <div className="p-4 border-t border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-3 px-2 py-2 mb-3">
          <div className="w-8 h-8 rounded-full bg-[#e6f7f5] dark:bg-teal-900/40 text-[#008f7a] dark:text-teal-400 flex items-center justify-center text-[14px] font-bold uppercase">
            {currentUser.charAt(0)}
          </div>
          <div className="flex flex-col text-left overflow-hidden">
            <span className="text-[13px] font-semibold text-slate-800 dark:text-slate-200 truncate">{currentUser === 'admin' ? 'System Administr...' : currentUser}</span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400 capitalize">{currentUser === 'admin' ? 'Administrator' : 'Member'}</span>
          </div>
        </div>
        <button 
          onClick={toggleDarkMode}
          className="w-full flex items-center justify-between px-3 py-2 mb-2 text-[14px] font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 rounded-lg transition-colors"
        >
          <div className="flex items-center gap-3">
            {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {isDarkMode ? 'Light Mode' : 'Dark Mode'}
          </div>
        </button>

        <button 
          onClick={onLogout}
          className="w-full flex items-center gap-2 px-3 py-2 text-[14px] font-semibold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </aside>
  );
}
