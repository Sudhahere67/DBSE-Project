import { Book, User, BorrowingRecord } from '../types';
import { useState } from 'react';

interface BorrowingsListProps {
  books: Book[];
  users: User[];
  records: BorrowingRecord[];
  onMarkReturned: (id: string) => void;
}

export function BorrowingsList({ books, users, records, onMarkReturned }: BorrowingsListProps) {
  const [activeTab, setActiveTab] = useState<'Active' | 'Overdue' | 'Returned' | 'All'>('Active');

  const getFilteredRecords = () => {
    if (activeTab === 'All') return records;
    return records.filter(r => r.status === activeTab);
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <div>
        <h1 className="text-[28px] font-bold text-slate-800 tracking-tight">Borrowing Management</h1>
        <p className="text-[15px] text-slate-500 mt-1">Track issues, returns, and overdue books.</p>
      </div>

      <div className="flex bg-slate-50 border border-slate-200 rounded-lg p-1 w-max">
        {['Active', 'Overdue', 'Returned', 'All Records'].map((tab) => {
          const tabId = tab === 'All Records' ? 'All' : tab;
          const isActive = activeTab === tabId;
          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tabId as any)}
              className={`px-5 py-2 text-[14px] font-medium rounded-md transition-colors ${
                isActive 
                  ? 'bg-white text-slate-800 shadow-sm border border-slate-200/50' 
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>

      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden mt-6">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse min-w-[900px]">
            <thead>
              <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider bg-[#fafafa]">
                <th className="px-6 py-4">BOOK</th>
                <th className="px-6 py-4">MEMBER</th>
                <th className="px-6 py-4">ISSUE / DUE DATE</th>
                <th className="px-6 py-4">STATUS</th>
                <th className="px-6 py-4 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {getFilteredRecords().map((record) => {
                const book = books.find(b => b.id === record.bookId);
                const user = users.find(u => u.id === record.userId);
                
                if (!book || !user) return null;

                const isOverdue = record.status === 'Overdue';
                const issueDateStr = new Date(record.borrowDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
                const dueDateStr = new Date(record.dueDate).toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
                
                // Calculate rough days overdue for mock data
                let daysOverdueStr = '';
                if (isOverdue) {
                   const due = new Date(record.dueDate).getTime();
                   const now = new Date('2026-09-16T00:00:00Z').getTime(); // static point in time matching screenshots
                   const diff = Math.max(0, Math.floor((now - due) / (1000 * 60 * 60 * 24)));
                   daysOverdueStr = `(${diff}d)`;
                }

                return (
                  <tr key={record.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900">{book.title}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">{book.author}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-[15px] text-slate-900 capitalize">{user.name}</div>
                      <div className="text-[13px] text-slate-500 mt-0.5">{user.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-[14px] text-slate-700">Issued: {issueDateStr}</div>
                      <div className={`text-[13px] font-medium mt-0.5 ${isOverdue ? 'text-red-600' : 'text-slate-500'}`}>
                        Due: {dueDateStr}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[12px] font-medium ${
                        record.status === 'Active' ? 'bg-teal-50 text-teal-700' :
                        record.status === 'Overdue' ? 'bg-red-50 text-red-700' :
                        'bg-slate-100 text-slate-700'
                      }`}>
                        {record.status} {daysOverdueStr}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      {record.status !== 'Returned' && (
                        <button 
                          onClick={() => onMarkReturned(record.id)}
                          className="px-4 py-2 bg-[#008f7a] hover:bg-[#007a68] text-white text-[13px] font-medium rounded-lg transition-colors"
                        >
                          Mark Returned
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
