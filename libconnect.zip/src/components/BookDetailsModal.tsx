import { X, Heart, BookOpen, Layers, Globe, Calendar, User as UserIcon } from 'lucide-react';
import { Book } from '../types';

interface BookDetailsModalProps {
  book: Book;
  isOpen: boolean;
  onClose: () => void;
  isFavorited: boolean;
  onToggleFavorite: (bookId: string) => void;
}

export function BookDetailsModal({ book, isOpen, onClose, isFavorited, onToggleFavorite }: BookDetailsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 sm:py-12">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row max-h-[90vh]">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/20 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 dark:text-slate-400 backdrop-blur-md transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Cover Section */}
        <div className="w-full md:w-2/5 bg-slate-100 dark:bg-slate-800 relative flex-shrink-0 flex items-center justify-center p-8">
          {book.coverUrl ? (
            <img 
              src={book.coverUrl} 
              alt={book.title} 
              className="w-full h-auto max-h-[60vh] object-contain rounded-lg shadow-lg"
            />
          ) : (
            <div className="w-full aspect-[2/3] max-h-[60vh] flex items-center justify-center text-center p-6 bg-slate-200 dark:bg-slate-700 rounded-lg">
              <span className="text-slate-400 dark:text-slate-500 font-medium">{book.title}</span>
            </div>
          )}
        </div>

        {/* Details Section */}
        <div className="w-full md:w-3/5 p-6 md:p-10 overflow-y-auto">
          <div className="flex items-start justify-between gap-4 mb-2">
            <div>
              <span className="inline-block px-2.5 py-1 rounded-md text-[11px] font-bold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 mb-3">
                {book.category}
              </span>
              <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white leading-tight">
                {book.title}
              </h2>
            </div>
            
            <button 
              onClick={() => onToggleFavorite(book.id)}
              className={`flex-shrink-0 p-3 rounded-full transition-colors ${
                isFavorited 
                  ? 'bg-rose-50 dark:bg-rose-500/10 text-rose-500' 
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300'
              }`}
            >
              <Heart className={`w-5 h-5 ${isFavorited ? 'fill-rose-500' : ''}`} />
            </button>
          </div>
          
          <div className="flex items-center gap-2 text-slate-600 dark:text-slate-300 mb-6 text-[15px]">
            <UserIcon className="w-4 h-4 text-slate-400" />
            <span>{book.author}</span>
          </div>

          <div className="prose prose-slate dark:prose-invert text-[15px] leading-relaxed mb-8 text-slate-600 dark:text-slate-300">
            {book.description ? (
              <p>{book.description}</p>
            ) : (
              <p className="italic text-slate-400 dark:text-slate-500">No description available for this book.</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className="text-[12px] font-medium text-slate-500 dark:text-slate-400 mb-1 flex items-center gap-1.5">
                <BookOpen className="w-3.5 h-3.5" /> ISBN
              </div>
              <div className="text-[14px] font-semibold text-slate-800 dark:text-slate-200">{book.isbn}</div>
            </div>
            
            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className="text-[12px] font-medium text-slate-500 dark:text-slate-400 mb-1 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" /> Pages
              </div>
              <div className="text-[14px] font-semibold text-slate-800 dark:text-slate-200">{book.pages || 'N/A'}</div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className="text-[12px] font-medium text-slate-500 dark:text-slate-400 mb-1 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" /> Language
              </div>
              <div className="text-[14px] font-semibold text-slate-800 dark:text-slate-200">{book.language || 'English'}</div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
              <div className="text-[12px] font-medium text-slate-500 dark:text-slate-400 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5" /> Published
              </div>
              <div className="text-[14px] font-semibold text-slate-800 dark:text-slate-200">
                {book.publishedYear ? `${book.publisher ? book.publisher + ', ' : ''}${book.publishedYear}` : 'N/A'}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-6 border-t border-slate-100 dark:border-slate-800">
            <div>
              <div className="text-[13px] text-slate-500 dark:text-slate-400 mb-1">Status</div>
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full ${book.status === 'Available' ? 'bg-[#008f7a]' : 'bg-amber-500'}`}></span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {book.status === 'Available' ? `${book.availableStock} of ${book.totalStock} available` : 'Currently borrowed'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
