import { Book, User, BorrowingRecord, Reservation, Fine } from '../types';
import { BookOpen, Users, Clock, AlertCircle, Bookmark } from 'lucide-react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';

interface DashboardProps {
  books: Book[];
  users: User[];
  records: BorrowingRecord[];
  reservations: Reservation[];
  fines: Fine[];
}

export function Dashboard({ books, users, records, reservations, fines }: DashboardProps) {
  const totalBooks = books.reduce((sum, book) => sum + book.totalStock, 0) + 124; // keeping padding so pie chart matches visually if we want
  const availableBooks = books.reduce((sum, book) => sum + book.availableStock, 0) + 103;

  const totalMembers = users.filter(u => u.role === 'Member').length;
  const currentlyBorrowed = records.filter(r => r.status === 'Active' || r.status === 'Overdue').length;
  const activeReservations = reservations.filter(r => r.status === 'Pending').length;
  const outstandingFines = fines.filter(f => f.status === 'Pending').reduce((sum, f) => sum + f.amount, 0);

  const PIE_DATA = [
    { name: 'Autobiography', value: 15, color: '#d97706' },
    { name: 'Classic Fiction', value: 25, color: '#134e4a' },
    { name: 'Contemporary Fiction', value: 20, color: '#f59e0b' },
    { name: 'Mythological Fiction', value: 10, color: '#115e59' },
    { name: 'Non-Fiction', value: 10, color: '#f97316' },
    { name: 'Personal Finance', value: 10, color: '#0f766e' },
    { name: 'Self-Development', value: 10, color: '#0d9488' },
  ];

  const BAR_DATA = [
    { name: 'Active', value: currentlyBorrowed },
    { name: 'Returned', value: records.filter(r => r.status === 'Returned').length },
    { name: 'Reservations', value: activeReservations },
  ];

  return (
    <div className="space-y-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-[32px] font-bold text-[#0f172a] tracking-tight">Admin Dashboard</h1>
        <p className="text-[15px] text-slate-500 mt-1">Overview of library operations and statistics.</p>
      </div>

      <div className="flex flex-col gap-6">
        {/* Top Row - 3 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-[140px]">
          {/* Total Books Card (Dark) */}
          <div className="bg-[#111827] p-6 rounded-xl shadow-sm relative flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-[#94a3b8] text-[13px] font-medium">Total Books (Copies)</h3>
                <div className="text-[36px] font-bold text-white mt-1 leading-none">{totalBooks}</div>
              </div>
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="mt-4">
              <span className="text-[#2dd4bf] text-[13px] font-semibold">{availableBooks}</span>
              <span className="text-[#94a3b8] text-[13px]"> copies currently available</span>
            </div>
          </div>

          {/* Total Members */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm relative flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-[#64748b] text-[13px] font-medium">Total Members</h3>
                <div className="text-[36px] font-bold text-[#0f172a] mt-1 leading-none">{totalMembers}</div>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#f0fdfa] flex items-center justify-center">
                <Users className="w-6 h-6 text-[#0d9488]" />
              </div>
            </div>
          </div>

          {/* Currently Borrowed */}
          <div className="bg-white border border-slate-200 p-6 rounded-xl shadow-sm relative flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-[#64748b] text-[13px] font-medium">Currently Borrowed</h3>
                <div className="text-[36px] font-bold text-[#0f172a] mt-1 leading-none">{currentlyBorrowed}</div>
              </div>
              <div className="w-12 h-12 rounded-full bg-[#eff6ff] flex items-center justify-center">
                <Clock className="w-6 h-6 text-[#2563eb]" />
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Row - 2 Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 h-[100px]">
          {/* Active Reservations */}
          <div className="bg-white border border-slate-200 p-5 px-6 rounded-xl shadow-sm relative flex items-center justify-between col-span-1 lg:col-span-1">
            <div>
              <h3 className="text-[#64748b] text-[13px] font-medium">Active Reservations</h3>
              <div className="text-[28px] font-bold text-[#0f172a] mt-1 leading-none">{activeReservations}</div>
            </div>
            <div className="w-12 h-12 rounded-full bg-[#fffbeb] flex items-center justify-center">
              <Bookmark className="w-6 h-6 text-[#d97706]" />
            </div>
          </div>

          {/* Outstanding Fines */}
          <div className="bg-white border border-slate-200 p-5 px-6 rounded-xl shadow-sm relative flex items-center justify-between col-span-1 lg:col-span-1">
            <div>
              <h3 className="text-[#64748b] text-[13px] font-medium">Outstanding Fines</h3>
              <div className="text-[28px] font-bold text-[#dc2626] mt-1 leading-none">₹{outstandingFines}</div>
            </div>
            <div className="w-12 h-12 rounded-full bg-[#fef2f2] flex items-center justify-center">
              <AlertCircle className="w-6 h-6 text-[#dc2626]" />
            </div>
          </div>
          
          <div className="hidden lg:block col-span-1"></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[400px]">
        {/* Books by Category Chart */}
        <div className="bg-white border border-slate-100 p-6 rounded-xl shadow-sm flex flex-col">
          <h3 className="text-[16px] font-medium text-slate-800 mb-6">Books by Category (Top 7)</h3>
          <div className="flex-1 min-h-0 relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={PIE_DATA}
                  cx="50%"
                  cy="45%"
                  innerRadius="55%"
                  outerRadius="80%"
                  paddingAngle={3}
                  dataKey="value"
                  stroke="none"
                >
                  {PIE_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </div>
          {/* Custom Legend */}
          <div className="mt-4 flex flex-wrap justify-center gap-x-4 gap-y-2 text-[12px] text-slate-600">
            {PIE_DATA.map((item, idx) => (
              <div key={idx} className="flex items-center gap-1.5">
                <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: item.color }}></div>
                <span>{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Activity Overview Chart */}
        <div className="bg-white border border-slate-100 p-6 rounded-xl shadow-sm flex flex-col">
          <h3 className="text-[16px] font-medium text-slate-800 mb-6">Activity Overview</h3>
          <div className="flex-1 min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={BAR_DATA} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 13 }} 
                  dy={10}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 13 }}
                  ticks={[0, 0.75, 1.5, 2.25, 3]}
                  domain={[0, 3]}
                />
                <Bar dataKey="value" fill="#008f7a" radius={[2, 2, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
